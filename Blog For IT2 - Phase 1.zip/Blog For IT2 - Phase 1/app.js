/* Author: Graham Gibney
Student Num: R00206659
Project phase 1: Blogs */


/* get the dependencies for the project
declare them as variables */
var { render } = require('ejs');
var express = require('express');
var mongoose = require('mongoose');
var logger = require('morgan');
var blogRoutes = require('./routes/blogRoutes');
var cookieParse = require('cookie-parser');
var contentDisposition = require('content-disposition');
const { options } = require('./routes/blogRoutes');


// create the app
const app = express();

/* ************************************************************
*This code was used to connect mongodb on my local machine
*I searched for a way to share the db contents when sharing 
*the code for submission. A cloud database seemed the best 
*options. A little research pointed to Atlas and that is the 
*db the new code points to

*old db connection code
*var dbUrl = 'mongodb://localhost:27017/newBlog';
*var connect = mongoose.connect(dbUrl);
*connect.then((db) => {
*    console.log("Connected correctly to the server");
*}, (err) => {console.log(err); }); 
***************************************************************/


/* connect to mongodb through mongo atlas cloud
This also allows the app to start without the need
to run two terminals/cmd prompts to connect to mongo */
var dbUrl = 'mongodb+srv://wookie:wookie@wookieblogs.m0irs.mongodb.net/WookieBlogs?retryWrites=true&w=majority';
mongoose.connect(dbUrl)
    .then((result) => console.log('Connected to Wookies DB on Atlas'))
    .catch((err) => console.log(err));

// start listening
app.listen(3000);

// register the view engine
app.set('view engine', 'ejs');


// format the logs to be printed to the log/terminal with morgan
app.use(logger('dev'));

/* middleware & static files 
- lets me use css and the public folder for css
- the method to recognize the incoming Request
  objects as strings or arrays */
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

// mongoose and mongo sandbox routes
// format for creating a blog and what is required
app.get('/create-blog', (req, res) => {
    const blog = new Blog({
        title: 'New Blog',
        blurb: 'A Wee Description',
        contents: 'Content of the Blog'
    });
    // send it to the db
    blog.save()
        .then((result) => {
            res.send(result)
        })
        .catch((err) => {
            console.log(err);
        });
});

// get all blogs from the db to display on the page
app.get('/all-blogs', (req, res) => {
    Blog.find()
        .then((result) => {
            res.send(result);
        })
        .catch((err) => {
            console.log(err);
        });
});

// home of the routes - setting up the responses to the GET request

/* want the user to get the blogs page when they hit localhost:3000 in the url bar - redirect
the three pages for phase 1 - home, about, help
the fourth page, create a blog, is associated with mongo above - line 31 */
app.get('/', (req, res) => {
    res.redirect('blogs')
});

app.get('/about', (req, res) => {
    res.render('about', { title: 'About' });
});

app.get('/help', (req, res) => {
    res.render('help', { title: 'Help' });
});

// use routes for tidying up the paths
app.use('/blogs', blogRoutes);

// generate a 404 page
app.use((req, res) => {
    res.status(404).render('404', { title: '404'});
});
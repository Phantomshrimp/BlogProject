/* create a variable Blog with the title, blurb, contents structre
imported from blogs.js */
var Blog = require('../models/blog');

// find and display the blogs created on the home page
var blog_index = (req, res) => {
    // display them newest to oldest
    Blog.find().sort({ createdAt: -1 })
        .then((result) => {
            res.render('blogs/index', { title: 'All Blogs', blogs: result} )
        })
        .catch((err) => {
            console.log(err);
        });
}

var blog_details = (req, res) => {
    var id = req.params.id;
    Blog.findById(id)
        .then(result => {
           res.render('blogs/details', { blog:result, title: 'Blog Details' });
        })
        .catch(err => {
            res.status(404).render('404', { title: 'No Blog For you!' });
        });
    }

// what to return when someone wants to create a blog
var blog_create_get = (req, res) => {
    res.render('blogs/create', { title: 'Create a new Blog' });
}

/* once the information has been entered
call a POST to create the blog */
var blog_create_post = (req, res) => {
    var blog = new Blog(req.body);

    // save it to the DB
    blog.save()
        .then((result) => {
            /* once user presses the submit button do the following
            save the blog to db > redirect to the home page */
            res.redirect('/blogs');
        })
        .catch((err) => {
            console.log(err);
        })
}

// now export them so we can use them throughout the code
module.exports = {
    blog_index,
    blog_details,
    blog_create_get,
    blog_create_post
}
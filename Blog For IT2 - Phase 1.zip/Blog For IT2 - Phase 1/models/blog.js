/* make the schema/collections in mongo
this entails getting the mongoose app and then using it */
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

var blogStyle = new Schema({
    // each entry is of type string and must be filled out, ie no NULLs
    title: {
        type: String,
        required: true
    },
    blurb: {
        type: String,
        required: true
    },
    contents: {
        type: String,
        required: true
    }
    // get mongo to auto assign timestamps
}, {
    timestamps: true
});

/* export the Blog model to allow a blog 
to be created with the format made above */
const Blog = mongoose.model('Blog', blogStyle);
module.exports = Blog;

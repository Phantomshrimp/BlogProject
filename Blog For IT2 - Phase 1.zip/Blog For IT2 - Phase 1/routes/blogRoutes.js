// setting up ye olde routes for indexing, creating and id'ing a blog
var express = require('express');
var blogControl = require('../controllers/blogControls');
var router = express.Router();

// these are the blog routes
router.get('/', blogControl.blog_index);
router.post('/', blogControl.blog_create_post);
router.get('/create', blogControl.blog_create_get);
router.get('/:id', blogControl.blog_details);

// export 'em to use 'em
module.exports = router;
